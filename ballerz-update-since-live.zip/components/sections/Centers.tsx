import Link from "next/link";
import Section from "@/components/ui/Section";
import MediaSlot from "@/components/ui/MediaSlot";
import { centers, centerStatusMeta } from "@/data/centers";
import { cta, features } from "@/data/site";
import { cn, delay } from "@/lib/cn";

export default function Centers({
  index = "02",
  showHeadline = true,
}: {
  index?: string;
  showHeadline?: boolean;
}) {
  return (
    <Section
      id="centers"
      index={index}
      label="TRAINING CENTERS"
      meta={`${String(centers.length).padStart(2, "0")} OPEN`}
      tone="ink2"
    >
      {showHeadline && (
        <div className="grid gap-7 md:grid-cols-12 md:gap-14">
          <div className="md:col-span-7">
            <h2 className="display t-h1" data-reveal>
              FIND YOUR
              <br />
              CENTER<span className="text-flare">.</span>
            </h2>
            <p className="display-he t-h2-he mt-4 text-bone" data-reveal style={delay(90)}>
              מרכזי BALLERZ
            </p>
          </div>
          <p className="body-he text-bone/70 md:col-span-5 md:pt-3" data-reveal style={delay(140)}>
            כל מרכז פועל לפי אותה תכנית, אותה שיטה ואותו סטנדרט. משנים את העיר — לא את
            המערכת.
          </p>
        </div>
      )}

      <ul className="mt-10 md:mt-14">
        {centers.map((c, i) => {
          const meta = centerStatusMeta[c.status];
          return (
            <li key={c.id} data-reveal style={delay(90 * i)}>
              <div className="group grid gap-6 border-t border-asphalt/35 py-8 last:border-b md:grid-cols-12 md:items-center md:gap-8">
                <div className="overflow-hidden md:col-span-3">
                  <MediaSlot
                    slot={`${c.cityEn} CENTER · B/W · 4:5`}
                    src={c.image}
                    alt={`מרכז BALLERZ ${c.city}`}
                    index={`C${i + 1}`}
                    ratio="4/5"
                    sizes="(max-width: 768px) 100vw, 24vw"
                    className="transition-transform duration-[1.2s] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.04]"
                  />
                </div>

                <div className="md:col-span-3">
                  <div className="flex items-center gap-3">
                    <span
                      className={cn(
                        "h-2 w-2 shrink-0",
                        meta.tone === "flare" && "bg-flare",
                        meta.tone === "bone" && "bg-bone/70",
                        meta.tone === "asphalt" && "bg-asphalt",
                      )}
                      aria-hidden
                    />
                    <span className="label-he text-flare">{c.statusLabel}</span>
                  </div>
                  <h3 className="mt-2 text-bone transition-colors duration-500 group-hover:text-flare">
                    <span className="display display-wide block text-[0.95rem] leading-none text-asphalt-2">
                      BALLERZ
                    </span>
                    <span className="display t-h3 mt-1.5 block leading-none">{c.cityEn}</span>
                  </h3>
                  <p className="display-he mt-2 text-[1.1rem] text-bone/85">{c.city}</p>
                </div>

                <dl className="grid grid-cols-2 gap-x-6 gap-y-4 md:col-span-4 md:grid-cols-2">
                  <Spec label="TRAINING DAY" value={c.trainingDay} />
                  <Spec label="TIME" value={c.trainingTime} />
                  <Spec label="AGES" value={c.ages} />
                  <Spec label="VENUE" value={c.location} />
                  <Spec label="LEVEL" value={c.level} />
                </dl>

                <div className="md:col-span-2 md:text-end">
                  <Link
                    href={`${cta.join.href}?center=${encodeURIComponent(c.city)}`}
                    className="group/btn inline-flex w-full items-center justify-between gap-4 border border-asphalt/45 px-5 py-4 text-sm text-bone transition-colors duration-400 hover:border-flare hover:bg-flare hover:text-ink sm:w-auto sm:justify-start"
                  >
                    הרשמה ל-{c.city}
                    <svg
                      aria-hidden
                      viewBox="0 0 24 12"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.6"
                      className="h-2.5 w-6 shrink-0 transition-transform duration-400 group-hover/btn:-translate-x-1"
                    >
                      <path d="M24 6H1M7 1L1 6l6 5" />
                    </svg>
                  </Link>
                </div>
              </div>
            </li>
          );
        })}
      </ul>

      <div className="mt-10 flex flex-col gap-4 border-t border-asphalt/25 pt-8 sm:flex-row sm:items-center sm:justify-between" data-reveal>
        <p className="body-he max-w-xl text-sm text-asphalt-2">
          רוצה מרכז BALLERZ בעיר שלך?{" "}
          <Link
            href={features.clubs ? cta.clubsTalk.href : cta.join.href}
            className="link-flare text-bone"
          >
            דברו איתנו
          </Link>
          .
        </p>
        <Link
          href={cta.combine.href}
          className="link-flare shrink-0 text-sm font-medium text-flare"
        >
          {cta.combine.label} ←
        </Link>
      </div>
    </Section>
  );
}

function Spec({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="spec spec-sm text-asphalt-2">{label}</dt>
      <dd className="body-he mt-1.5 text-sm text-bone/85">{value}</dd>
    </div>
  );
}
